﻿--- Attendance Table 
SET IDENTITY_INSERT attendance ON;
INSERT INTO Attendance (id, student_id, course_id, date, status) VALUES
(11, 1, 101, '2025-03-01', 'Present'),
(12, 2, 102, '2025-03-01', 'Absent'),
(13, 3, 103, '2025-03-02', 'Present'),
(14, 4, 104, '2025-03-02', 'Absent'),
(15, 5, 105, '2025-03-03', 'Present'),
(16, 6, 106, '2025-03-03', 'Absent'),
(17, 7, 107, '2025-03-04', 'Present'),
(18, 8, 108, '2025-03-04', 'Absent'),
(19, 9, 109, '2025-03-05', 'Present'),
(10, 10, 110, '2025-03-05', 'Absent');
SET IDENTITY_INSERT attendance OFF;