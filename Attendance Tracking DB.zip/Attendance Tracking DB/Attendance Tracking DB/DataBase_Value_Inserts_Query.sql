﻿--- Student Table
SET IDENTITY_INSERT students ON;
INSERT INTO Students (id, name, email) VALUES
(16, 'John Doe', 'john.doe@example.com'),
(7, 'Jane Smith', 'jane.smith@example.com'),
(8, 'Alice Johnson', 'alice.johnson@example.com'),
(9, 'Bob Brown', 'bob.brown@example.com'),
(10, 'Charlie Davis', 'charlie.davis@example.com'),
(11, 'Diana Evans', 'diana.evans@example.com'),
(12, 'Evan Fisher', 'evan.fisher@example.com'),
(13, 'Fiona Green', 'fiona.green@example.com'),
(14, 'George Harris', 'george.harris@example.com'),
(15, 'Hannah Jones', 'hannah.jones@example.com');
SET IDENTITY_INSERT students OFF;

--- Course Table 
SET IDENTITY_INSERT courses ON;
INSERT INTO Courses (id, name, description, course_number) VALUES
(111, 'Introduction to Programming', 'Learn the basics of programming using Python.', 'CS111'),
(102, 'Data Structures', 'Study various data structures and their applications.', 'CS102'),
(103, 'Database Systems', 'Introduction to database design and SQL.', 'CS103'),
(104, 'Web Development', 'Learn to build dynamic websites using HTML, CSS, and JavaScript.', 'CS104'),
(105, 'Operating Systems', 'Study the principles of operating systems.', 'CS105'),
(106, 'Computer Networks', 'Introduction to networking concepts and protocols.', 'CS106'),
(107, 'Software Engineering', 'Learn software development methodologies and practices.', 'CS107'),
(108, 'Artificial Intelligence', 'Introduction to AI concepts and techniques.', 'CS108'),
(109, 'Machine Learning', 'Learn the basics of machine learning algorithms and applications.', 'CS109'),
(110, 'Cybersecurity', 'Introduction to cybersecurity principles and practices.', 'CS110');
SET IDENTITY_INSERT courses OFF;

--- Enrollment Table 
SET IDENTITY_INSERT enrollments ON;
INSERT INTO Enrollments ( student_id, course_id) VALUES
( 1, 101),
( 2, 102),
( 3, 103),
( 4, 104),
( 5, 105),
( 6, 106),
( 7, 107),
( 8, 108),
( 9, 109),
( 10, 110);

SET IDENTITY_INSERT enrollments OFF;
