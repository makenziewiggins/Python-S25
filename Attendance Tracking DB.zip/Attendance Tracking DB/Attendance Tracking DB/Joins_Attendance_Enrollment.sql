﻿-- Assuming the tables are named 'attendance' and 'enrollments'  
-- and the relevant columns are 'student_id', 'course_id', and 'date' in 'attendance'  
-- and 'student_id', 'course_id' in 'enrollments'  

-- Insert missing enrollments based on attendance records  
INSERT INTO enrollments(student_id, course_id)  
SELECT DISTINCT a.student_id, a.course_id  
FROM attendance a  
LEFT JOIN enrollments e  
ON a.student_id = e.student_id AND a.course_id = e.course_id  
WHERE e.student_id IS NULL AND a.course_id IS NOT NULL;
