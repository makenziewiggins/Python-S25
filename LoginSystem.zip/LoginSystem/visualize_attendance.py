import tkinter as tk
from tkinter import messagebox
import matplotlib.pyplot as plt
import pyodbc
import pandas as pd


def fetch_attendance_data():
    try:
        conn = pyodbc.connect(
            'DRIVER={SQL Server};'
            'SERVER=(localdb)\\MSSQLLocalDB;' 
            'DATABASE=AttendanceTrackingDB;'  
            'Trusted_Connection=yes;'
        )

        query = """
        SELECT student_id, course_id, attendance_date
        FROM Attendance
        """
        df = pd.read_sql(query, conn)
        conn.close()
        return df

    except Exception as e:
        messagebox.showerror("Database Error", str(e))
        return None


def show_graphs():
    df = fetch_attendance_data()
    if df is None or df.empty:
        messagebox.showinfo("No Data", "No attendance records found.")
        return

    # Convert date column
    df['attendance_date'] = pd.to_datetime(df['attendance_date'])

    # Graph 1: Attendance by Course
    course_attendance = df['course_id'].value_counts().sort_index()
    plt.figure()
    course_attendance.plot(kind='bar')
    plt.title("Total Attendance by Course")
    plt.xlabel("Course ID")
    plt.ylabel("Attendance Count")
    plt.tight_layout()

    # Graph 2: Attendance Over Time
    attendance_over_time = df.groupby(df['attendance_date'].dt.date).size()
    plt.figure()
    attendance_over_time.plot(kind='line', marker='o')
