# attendance_summary_graphs.py
import matplotlib.pyplot as plt
import pyodbc
import pandas as pd
from tkinter import messagebox

def show_summary_graphs():
    try:
        query = "SELECT student_id, course_id, attendance_date FROM Attendance"

        with pyodbc.connect(
            r'DRIVER={ODBC Driver 17 for SQL Server};'
            r'SERVER=(localdb)\MSSQLLocalDB;'
            r'DATABASE=AttendanceTrackingDB;'
            r'Trusted_Connection=yes;'
        ) as conn:
            df = pd.read_sql(query, conn)

        if df.empty:
            messagebox.showinfo("No Data", "No attendance records found.")
            return

        df['attendance_date'] = pd.to_datetime(df['attendance_date'])

        # Graph 1: Attendance by Course
        plt.figure()
        df['course_id'].value_counts().sort_index().plot(kind='bar')
        plt.title("Total Attendance by Course")
        plt.xlabel("Course ID")
        plt.ylabel("Attendance Count")
        plt.tight_layout()

        # Graph 2: Attendance Over Time
        plt.figure()
        df.groupby(df['attendance_date'].dt.date).size().plot(kind='line', marker='o')
        plt.title("Attendance Over Time")
        plt.xlabel("Date")
        plt.ylabel("Number of Attendances")
        plt.tight_layout()

        plt.show()

    except Exception as e:
        print("Error loading graphs:", e)  # <- this shows the error in the terminal/console
        messagebox.showerror("Error", f"Failed to load graphs:\n{e}")


