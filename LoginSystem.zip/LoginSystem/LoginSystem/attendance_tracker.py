﻿import tkinter as tk
from tkinter import messagebox, ttk
from tkcalendar import DateEntry
import pyodbc

def launch_attendance_tracker():
    conn = pyodbc.connect(
        'DRIVER={ODBC Driver 17 for SQL Server};'
        'SERVER=(localdb)\\MSSQLLocalDB;'
        'DATABASE=AttendanceTrackingDB;'
        'Trusted_Connection=yes;'
    )
    cursor = conn.cursor()
    attendance_entries = []

    def validate_ids(student_id, course_id):
        cursor.execute("SELECT 1 FROM Students WHERE id = ?", student_id)
        student_exists = cursor.fetchone()
        cursor.execute("SELECT 1 FROM Courses WHERE id = ?", course_id)
        course_exists = cursor.fetchone()
        return student_exists and course_exists

    def check_duplicate(student_id, course_id, selected_date):
        cursor.execute("""
            SELECT 1 FROM Attendance
            WHERE student_id = ? AND course_id = ? AND date = ?
        """, (student_id, course_id, selected_date))
        return cursor.fetchone() is not None

    def add_attendance():
        student_id = student_id_entry.get()
        course_id = course_dict.get(course_var.get())
        status = status_var.get()
        selected_date = date_entry.get_date()

        if not student_id or not course_id:
            messagebox.showerror("Input Error", "Student ID and Course ID are required.")
            return

        if not validate_ids(student_id, course_id):
            messagebox.showerror("Validation Error", "Invalid Student ID or Course ID.")
            return

        if check_duplicate(student_id, course_id, selected_date):
            messagebox.showwarning("Duplicate Entry", "Attendance already recorded for this student on this date.")
            return

        attendance_entries.append((student_id, course_id, selected_date, status))
        messagebox.showinfo("Success", "Attendance added to batch list.")
        student_id_entry.delete(0, tk.END)
        course_var.set(list(course_dict.keys())[0])
        status_var.set("Present")

    def submit_batch():
        if not attendance_entries:
            messagebox.showwarning("Empty List", "No attendance records to submit.")
            return
        try:
            cursor.executemany("""
                INSERT INTO Attendance (student_id, course_id, date, status)
                VALUES (?, ?, ?, ?)
            """, attendance_entries)
            conn.commit()
            messagebox.showinfo("Success", "All attendance records submitted!")
            attendance_entries.clear()
        except Exception as e:
            messagebox.showerror("Database Error", str(e))

    def view_attendance_records():
        from attendance_viewer import view_attendance_records as viewer
        viewer()

    # === Window ===
    tracker_window = tk.Toplevel()
    tracker_window.title("Attendance Tracker")

    tk.Label(tracker_window, text="Student ID:").grid(row=0, column=0, pady=5, sticky="e")
    student_id_entry = tk.Entry(tracker_window)
    student_id_entry.grid(row=0, column=1)

    cursor.execute("SELECT id, name FROM Courses")
    courses = cursor.fetchall()
    course_dict = {f"{name} (ID: {course_id})": course_id for course_id, name in courses}
    course_var = tk.StringVar(tracker_window)
    course_var.set(list(course_dict.keys())[0])
    course_menu = tk.OptionMenu(tracker_window, course_var, *course_dict.keys())
    course_menu.grid(row=1, column=1, pady=5)

    tk.Label(tracker_window, text="Status:").grid(row=2, column=0, pady=5, sticky="e")
    status_var = tk.StringVar(tracker_window)
    status_var.set("Present")
    status_menu = tk.OptionMenu(tracker_window, status_var, "Present", "Absent")
    status_menu.grid(row=2, column=1, pady=5)

    tk.Label(tracker_window, text="Date:").grid(row=3, column=0, pady=5, sticky="e")
    date_entry = DateEntry(tracker_window, date_pattern='yyyy-mm-dd')
    date_entry.grid(row=3, column=1, pady=5)

    tk.Button(tracker_window, text="Add Attendance", command=add_attendance).grid(row=4, column=0, columnspan=2, pady=10)
    tk.Button(tracker_window, text="Submit Batch", command=submit_batch).grid(row=5, column=0, columnspan=2, pady=10)
    tk.Button(tracker_window, text="View Records", command=view_attendance_records).grid(row=6, column=0, columnspan=2, pady=10)
